using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SkillTreeManager : MonoBehaviour
{
    public SkillSlot[] skillSlot;
    public TMP_Text pointsText;
    public int availablePoints = 0;

    private void Start() {
        foreach (SkillSlot slot in skillSlot)
        {
            slot.skillButton.onClick.AddListener(slot.TryUpgradeSkill);
        }
        UpdateAbilityPoints(0);
    }

    public void UpdateAbilityPoints(int amount){
        availablePoints += amount;
        pointsText.text = "Points: " + availablePoints;
    }
}
